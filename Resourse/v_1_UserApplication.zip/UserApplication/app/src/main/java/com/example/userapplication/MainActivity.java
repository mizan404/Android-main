package com.example.userapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.TestActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnRegister, btnLogin, btnTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         btnRegister = findViewById(R.id.btnRegister);
         btnLogin = findViewById(R.id.btnLogin);
         btnTest = findViewById(R.id.btnTest);

        Button btnRegister = findViewById(R.id.btnRegister);
        Button btnLogin = findViewById(R.id.btnLogin);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent i = new Intent(MainActivity.this, RegisterActivity.class);
//                startActivity(i);
//                Toast t = new Toast(MainActivity.this);
//                t.setText("clicked 1");
//                t.setDuration(Toast.LENGTH_SHORT);
//                t.show();

                //Toast.makeText(MainActivity.this, "Clicked", Toast.LENGTH_SHORT).show();

                new AlertDialog.Builder(MainActivity.this).setTitle("Do you want to go to the Registration Page?").setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.M)
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Log.v("h", "hello");
                        //Toast.makeText(MainActivity.this, "Very very good", Toast.LENGTH_SHORT).show();
                        NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivity.this);

                        Intent notificationIntent = new Intent(MainActivity.this, MainActivity.class);
                        PendingIntent contentIntent = PendingIntent.getActivity(MainActivity.this, 0, notificationIntent,
                                PendingIntent.FLAG_UPDATE_CURRENT);

                        builder.setSmallIcon(R.drawable.ic_launcher_background);//1
                        builder.setContentTitle("Notifications Example"); //2
                        builder.setContentText("This is a test notification"); //3
                        builder.setContentIntent(contentIntent); //4


                        // Add as notification
                        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                        manager.notify(0, builder.build()); //5

                    }
                }).setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent i = new Intent(MainActivity.this, RegisterActivity.class);
                        startActivity(i);
                    }
                }).show();
            }
        });


//        btnLogin.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent i = new Intent(MainActivity.this, LoginActivity.class);
//                startActivity(i);
//            }
//        });
//
    }



    @Override
    public void onClick(View v1) {
        Log.v("test", "Testing");
//        if (v.getId() == btnRegister.getId()) {
//            Intent i = new Intent(MainActivity.this, RegisterActivity.class);
//            startActivity(i);
//        } else if (v.getId() == btnLogin.getId()) {
//            Intent i = new Intent(MainActivity.this, LoginActivity.class);
//            startActivity(i);
//        } else if (v.getId() == btnTest.getId()) {
//            Intent i = new Intent(MainActivity.this, TestActivity.class);
//            startActivity(i);
//        }
    }
}