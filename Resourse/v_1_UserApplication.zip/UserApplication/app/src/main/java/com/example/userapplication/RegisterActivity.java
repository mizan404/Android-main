package com.example.userapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.userapplication.model.User;
import com.example.userapplication.utils.DBHelper;

import java.util.ArrayList;
import java.util.List;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        DBHelper db = new DBHelper(this);
        Button btnRegister = findViewById(R.id.btnRegister);
        EditText username = findViewById(R.id.username);
        EditText password = findViewById(R.id.password);

        Spinner spinner = findViewById(R.id.spinner);

        List<String> list = new ArrayList<String>();
        list.add("Mr. AA");
        list.add("Mr. BB");
        list.add("Mr. CC");
        list.add("Mr. DD");

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(RegisterActivity.this, R.layout.support_simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        adapter.addAll(list);
        spinner.setAdapter(adapter);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.v("reg", "registration section");
                db.addUser(new User(username.getText().toString(), password.getText().toString()));
            }
        });

    }
}