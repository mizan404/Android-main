Firebase Demo

This is the code base for the tutorials uploded on Programming Knowledge Youtube Channel.
